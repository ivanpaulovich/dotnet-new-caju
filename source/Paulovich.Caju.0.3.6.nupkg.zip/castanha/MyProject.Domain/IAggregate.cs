﻿namespace MyProject.Domain
{
    public interface IAggregate : IEntity
    {
    }
}