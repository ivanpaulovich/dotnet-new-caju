﻿namespace MyProject.Application.ServiceBus
{
    public interface ISubscriber
    {
        void Listen();
    }
}
