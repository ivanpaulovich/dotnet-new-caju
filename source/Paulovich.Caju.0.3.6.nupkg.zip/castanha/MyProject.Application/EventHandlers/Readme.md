﻿You may thinking why you need Converters to expose data if you already have Entities.
By reusing Entities in the outter layers you create some coupling that are hard to change later.
We recomend functions to convert your Entities into Output format.