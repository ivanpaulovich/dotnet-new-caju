A Clean Architecture service template for your Application with 
DDD, TDD and SOLID using .NET Core 2.0. It has High Cohesion and Loose Coupling, 
it's a good start for your next Microservice application

https://github.com/ivanpaulovich/manga