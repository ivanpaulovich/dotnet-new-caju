﻿namespace MyProject.Infrastructure.Modules
{
    using Autofac;
	
    public class WebApiModule : Autofac.Module
    {
        protected override void Load(ContainerBuilder builder)
        {
            
        }
    }
}
